import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import yfinance as yf

st.set_page_config(page_title="Alpaca Trading Dashboard", layout="wide")

st.title("📊 Alpaca Trading Dashboard")

# Load Alpaca keys from Streamlit secrets
ALPACA_API_KEY = st.secrets["ALPACA_API_KEY"]
ALPACA_SECRET_KEY = st.secrets["ALPACA_SECRET_KEY"]

# Fetch account info
st.subheader("💼 Account Info")
res = requests.get(
    "https://paper-api.alpaca.markets/v2/account",
    headers={
        "APCA-API-KEY-ID": ALPACA_API_KEY,
        "APCA-API-SECRET-KEY": ALPACA_SECRET_KEY
    }
)
if res.status_code == 200:
    account = res.json()
    st.metric("Equity", f"${float(account['equity']):,.2f}")
    st.metric("Buying Power", f"${float(account['buying_power']):,.2f}")
    st.metric("Portfolio Value", f"${float(account['portfolio_value']):,.2f}")
else:
    st.error("Unable to fetch Alpaca account data. Check your API keys or network.")

# Positions
st.subheader("📈 Open Positions")
pos = requests.get(
    "https://paper-api.alpaca.markets/v2/positions",
    headers={
        "APCA-API-KEY-ID": ALPACA_API_KEY,
        "APCA-API-SECRET-KEY": ALPACA_SECRET_KEY
    }
)
if pos.status_code == 200:
    positions = pd.DataFrame(pos.json())
    if not positions.empty:
        positions["market_value"] = positions["market_value"].astype(float)
        fig = px.pie(positions, values="market_value", names="symbol", title="Portfolio Allocation")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(positions[["symbol", "qty", "market_value", "unrealized_pl"]])
    else:
        st.info("No open positions.")
else:
    st.error("Could not retrieve positions from Alpaca.")

# Optional: Market data lookup
st.subheader("🔍 Quick Stock Lookup")
symbol = st.text_input("Enter a stock symbol (e.g., AAPL, TSLA):")
if symbol:
    data = yf.download(symbol, period="1mo")
    if not data.empty:
        st.line_chart(data["Close"])
    else:
        st.warning("No data found for that symbol.")
